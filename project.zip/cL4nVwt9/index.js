function sendMessage() {
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  const chatBox = document.getElementById('chat-box');
  
  if (email && message) {
    const chatMessage = document.createElement('p');
    chatMessage.textContent = `${email}: ${message}`;
    chatBox.appendChild(chatMessage);
    
    let messages = JSON.parse(localStorage.getItem('messages')) || [];
    messages.push({ email, message });
    localStorage.setItem('messages', JSON.stringify(messages));
    
    // Clear input fields after sending message
    document.getElementById('email').value = '';
    document.getElementById('message').value = '';
  } else {
    alert('Please enter both email and message.');
  }
}
